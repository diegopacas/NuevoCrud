-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2019 at 09:25 AM
-- Server version: 5.6.45
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mjgl_democrudsis21a`
--
CREATE DATABASE IF NOT EXISTS `mjgl_democrudsis21a` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mjgl_democrudsis21a`;

-- --------------------------------------------------------

--
-- Table structure for table `tb_articulos`
--

CREATE TABLE `tb_articulos` (
  `codigo` int(11) NOT NULL,
  `descripcion` varchar(150) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `imagen` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_articulos`
--

INSERT INTO `tb_articulos` (`codigo`, `descripcion`, `precio`, `imagen`) VALUES
(299, 'Teclado Gen', 12.90, 'http://mjgl.com.sv/mysqlcrud/imagenes/uno.jpg'),
(100, 'SAMSUNG SMART TV', 700.99, 'http://mjgl.com.sv/mysqlcrud/imagenes/cinco.jpg'),
(555, 'Router', 58.99, 'http://mjgl.com.sv/mysqlcrud/imagenes/siete.jpg'),
(665, 'por', 123.00, 'http://mjgl.com.sv/mysqlcrud/imagenes/cuatro.jpg'),
(4, 'cable USB', 3.55, 'http://mjgl.com.sv/mysqlcrud/imagenes/dos.jpg'),
(885, 'gamez chovi', 25.96, 'http://mjgl.com.sv/mysqlcrud/imagenes/nueve.jpg'),
(25, 'Olga', 70.99, 'http://mjgl.com.sv/mysqlcrud/imagenes/ocho.jpg'),
(26, 'chacho', 321.00, 'http://mjgl.com.sv/mysqlcrud/imagenes/seis.jpg'),
(900, 'VENTILADOR', 55.99, 'http://mjgl.com.sv/mysqlcrud/imagenes/spo2.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_articulos`
--
ALTER TABLE `tb_articulos`
  ADD PRIMARY KEY (`codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
